from django.apps import AppConfig


class AlbumappConfig(AppConfig):
    name = 'albumApp'
